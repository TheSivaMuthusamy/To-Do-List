# To-Do-List

An electron-based ToDoList app built in React using the material-ui package. The list is stored locally, and adding to the list is as simple as typing it in the text area and hitting the enter key. Clicking on the checkbox next to items on the list deletes them from the list.

---

###  Installation

- `npm install`
- `npm run electron`